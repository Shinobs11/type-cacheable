export interface CacheKeyBuilder {
  (args: any[], context?: any): string;
};
