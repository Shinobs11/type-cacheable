export interface CacheManagerOptions {
  ttlSeconds?: number;
}
