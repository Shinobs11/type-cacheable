export { RedisAdapter } from './RedisAdapter';
